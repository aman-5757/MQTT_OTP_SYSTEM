
import paho.mqtt.client as mqtt
import time
import random



def lambda_handler(event, context):


    def on_connect(client, userdata, flags, rc):
        print("Connected with code :"+str(rc))
        client.subscribe("test_folder")
    def on_message(client, userdata, msg):
        print(str(msg.payload))
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.username_pw_set("user_name", "password")
    client.connect("domain_name", 1883, 60)
    client.loop_start()
    time.sleep(1)
    client.publish("test_folder", random.randint(1000,9999), qos =1)
    print('msg sent! by aman5757')
    time.sleep(15)
    client.loop_stop()
    client.disconnect()
